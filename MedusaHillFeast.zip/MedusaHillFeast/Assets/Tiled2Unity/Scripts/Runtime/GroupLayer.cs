﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;

namespace Tiled2Unity
{
    public class GroupLayer : Tiled2Unity.Layer
    {
        // No special properties on GroupLayer
    }
}
