﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuestObject : MonoBehaviour {

    //private bool inTrigger = false;

    public List<int> avaliableQuestIDs = new List<int>();
    //public List<int> currQuestIDs = new List<int>();

    // Use this for initialization
    void Start () {
		
	}
	
	// Update 
	void Update () {
		
	}
}
