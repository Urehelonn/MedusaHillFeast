<?xml version="1.0" encoding="UTF-8"?>
<tileset name="baseSet" tilewidth="16" tileheight="16" tilecount="14758" columns="94">
 <image source="../Art/sprite3.png" width="1504" height="2519"/>
 <terraintypes>
  <terrain name="table1" tile="369"/>
 </terraintypes>
 <tile id="369" terrain=",,,0">
  <objectgroup draworder="index">
   <object id="2" x="0.181818" y="4.54545" width="15.9091" height="11.4545"/>
  </objectgroup>
 </tile>
 <tile id="370" terrain=",,0,">
  <objectgroup draworder="index">
   <object id="2" x="0.0909091" y="5.81818" width="16" height="10.0909"/>
  </objectgroup>
 </tile>
 <tile id="463" terrain=",0,,">
  <objectgroup draworder="index">
   <object id="8" x="-0.0869565" y="-0.130435" width="16.2609" height="16.1304"/>
  </objectgroup>
 </tile>
 <tile id="464" terrain="0,,,">
  <objectgroup draworder="index">
   <object id="1" x="-0.173913" y="-0.0869565" width="16.3478" height="16.2174"/>
  </objectgroup>
 </tile>
 <tile id="733">
  <objectgroup draworder="index">
   <object id="1" x="2.3913" y="0.0869565" width="10.8261" height="16.0435"/>
  </objectgroup>
 </tile>
 <tile id="734">
  <objectgroup draworder="index">
   <object id="1" x="3.73913" y="0.26087" width="9.13043" height="15.6087"/>
  </objectgroup>
 </tile>
 <tile id="735">
  <objectgroup draworder="index">
   <object id="1" x="2.91304" y="0.0434783" width="10.087" height="16.0435"/>
  </objectgroup>
 </tile>
 <tile id="827">
  <objectgroup draworder="index">
   <object id="1" x="3.08696" y="0" width="9.04348" height="16.087"/>
  </objectgroup>
 </tile>
 <tile id="828">
  <objectgroup draworder="index">
   <object id="1" x="2.78261" y="0.130435" width="9.3913" height="15.9565"/>
  </objectgroup>
 </tile>
 <tile id="829">
  <objectgroup draworder="index">
   <object id="1" x="3.04348" y="0.0434783" width="9.17391" height="15.913"/>
  </objectgroup>
 </tile>
 <tile id="1015">
  <objectgroup draworder="index">
   <object id="1" x="-0.0434783" y="-0.0869565" width="16.087" height="16.1739"/>
  </objectgroup>
 </tile>
 <tile id="1016">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16.087" height="16.0435"/>
  </objectgroup>
 </tile>
 <tile id="1109">
  <objectgroup draworder="index">
   <object id="1" x="-0.130435" y="-0.0434783" width="16.2174" height="16.0435"/>
  </objectgroup>
 </tile>
 <tile id="1110">
  <objectgroup draworder="index">
   <object id="1" x="-0.0869565" y="-0.0869565" width="16.2174" height="16.1304"/>
  </objectgroup>
 </tile>
 <tile id="1204">
  <objectgroup draworder="index">
   <object id="1" x="1.95652" y="0.217391" width="12.9565" height="13.5652"/>
  </objectgroup>
 </tile>
 <tile id="1205">
  <objectgroup draworder="index">
   <object id="1" x="1.82609" y="-0.130435" width="12.3913" height="14.1304"/>
  </objectgroup>
 </tile>
 <tile id="1206">
  <objectgroup draworder="index">
   <object id="1" x="1.82609" y="0.0869565" width="12.5652" height="13.5652"/>
  </objectgroup>
 </tile>
 <tile id="1207">
  <objectgroup draworder="index">
   <object id="1" x="1.34783" y="-0.347826" width="12.7391" height="13.1304"/>
  </objectgroup>
 </tile>
 <tile id="1298">
  <objectgroup draworder="index">
   <object id="1" x="1.95652" y="-0.173913" width="12.2174" height="13.5652"/>
  </objectgroup>
 </tile>
 <tile id="1299">
  <objectgroup draworder="index">
   <object id="1" x="2.3913" y="-0.304348" width="11.2174" height="13.4348"/>
  </objectgroup>
 </tile>
 <tile id="1300">
  <objectgroup draworder="index">
   <object id="1" x="1.6087" y="-0.304348" width="12.4783" height="14.0435"/>
  </objectgroup>
 </tile>
 <tile id="1301">
  <objectgroup draworder="index">
   <object id="1" x="2.13043" y="-0.304348" width="11.7826" height="13.2174"/>
  </objectgroup>
 </tile>
 <tile id="1968">
  <objectgroup draworder="index">
   <object id="1" x="4" y="-1.21739" width="12.3043" height="17.4783"/>
  </objectgroup>
 </tile>
 <tile id="1969">
  <objectgroup draworder="index">
   <object id="1" x="-0.0434783" y="-1.04348" width="12.3043" height="17.4348"/>
  </objectgroup>
 </tile>
 <tile id="1970">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="1971">
  <objectgroup draworder="index">
   <object id="1" x="2.08696" y="5.52174" width="12" height="10.8261"/>
  </objectgroup>
 </tile>
 <tile id="2062">
  <objectgroup draworder="index">
   <object id="1" x="4.30435" y="-0.956522" width="11.8696" height="17.087"/>
  </objectgroup>
 </tile>
 <tile id="2063">
  <objectgroup draworder="index">
   <object id="1" x="-0.347826" y="-1.3913" width="12.4348" height="18.3913"/>
  </objectgroup>
 </tile>
 <tile id="2064">
  <objectgroup draworder="index">
   <object id="1" x="2.47826" y="-1.65217" width="10.7391" height="8.82609"/>
  </objectgroup>
 </tile>
 <tile id="2065">
  <objectgroup draworder="index">
   <object id="1" x="3" y="-1.43478" width="10.087" height="8.43478"/>
  </objectgroup>
 </tile>
 <tile id="2156">
  <objectgroup draworder="index">
   <object id="1" x="13.9565" y="14.8261" width="2.26087" height="1.3913"/>
  </objectgroup>
 </tile>
 <tile id="2157">
  <objectgroup draworder="index">
   <object id="1" x="-0.173913" y="14.6087" width="9.26087" height="1.78261"/>
  </objectgroup>
 </tile>
 <tile id="2250">
  <objectgroup draworder="index">
   <object id="1" x="3.86957" y="-2.47826" width="13.1739" height="19.6087"/>
  </objectgroup>
 </tile>
 <tile id="2251">
  <objectgroup draworder="index">
   <object id="1" x="-0.391304" y="-0.521739" width="12.4783" height="17"/>
  </objectgroup>
 </tile>
 <tile id="2252">
  <objectgroup draworder="index">
   <object id="1" x="0.73913" y="0.608696" width="15.9565" height="15.8261"/>
  </objectgroup>
 </tile>
 <tile id="2253">
  <objectgroup draworder="index">
   <object id="1" x="-0.173913" y="0.956522" width="15.4348" height="15.3478"/>
  </objectgroup>
 </tile>
 <tile id="2254">
  <objectgroup draworder="index">
   <object id="1" x="0.956522" y="1.04348" width="15.3478" height="14.9565"/>
  </objectgroup>
 </tile>
 <tile id="2255">
  <objectgroup draworder="index">
   <object id="1" x="-0.0869565" y="1" width="15.0435" height="15.3478"/>
  </objectgroup>
 </tile>
 <tile id="2344">
  <objectgroup draworder="index">
   <object id="2" x="3.86957" y="-1.47826" width="12.3913" height="17.6522"/>
  </objectgroup>
 </tile>
 <tile id="2345">
  <objectgroup draworder="index">
   <object id="1" x="-0.0869565" y="-1.91304" width="12.1739" height="18.6957"/>
  </objectgroup>
 </tile>
 <tile id="2346">
  <objectgroup draworder="index">
   <object id="1" x="1.08696" y="-1.04348" width="15.0435" height="15.9565"/>
  </objectgroup>
 </tile>
 <tile id="2347">
  <objectgroup draworder="index">
   <object id="1" x="-0.130435" y="-0.26087" width="15.1304" height="15.1739"/>
  </objectgroup>
 </tile>
 <tile id="2348">
  <objectgroup draworder="index">
   <object id="1" x="1" y="-0.956522" width="15.2609" height="15.9565"/>
  </objectgroup>
 </tile>
 <tile id="2349">
  <objectgroup draworder="index">
   <object id="1" x="-0.347826" y="-0.130435" width="15.4348" height="15.1304"/>
  </objectgroup>
 </tile>
 <tile id="2440">
  <objectgroup draworder="index">
   <object id="1" x="1.04348" y="1.95652" width="15.1739" height="14.8696"/>
  </objectgroup>
 </tile>
 <tile id="2441">
  <objectgroup draworder="index">
   <object id="1" x="-0.0869565" y="1.95652" width="15.2609" height="14.1304"/>
  </objectgroup>
 </tile>
 <tile id="2534">
  <objectgroup draworder="index">
   <object id="1" x="1.04348" y="-0.434783" width="15.913" height="16.6087"/>
  </objectgroup>
 </tile>
 <tile id="2535">
  <objectgroup draworder="index">
   <object id="1" x="-0.0434783" y="-0.130435" width="15.2174" height="16.1304"/>
  </objectgroup>
 </tile>
 <tile id="2615">
  <objectgroup draworder="index">
   <object id="1" x="1.17391" y="8.95652" width="13.913" height="8.43478"/>
  </objectgroup>
 </tile>
 <tile id="2616">
  <objectgroup draworder="index">
   <object id="1" x="1.30435" y="8.95652" width="13.1304" height="8.69565"/>
  </objectgroup>
 </tile>
 <tile id="2617">
  <objectgroup draworder="index">
   <object id="1" x="0.73913" y="9.04348" width="14.4783" height="7.69565"/>
  </objectgroup>
 </tile>
 <tile id="2618">
  <objectgroup draworder="index">
   <object id="1" x="1.30435" y="9.43478" width="13.3913" height="8.17391"/>
  </objectgroup>
 </tile>
 <tile id="2619">
  <objectgroup draworder="index">
   <object id="1" x="2.04348" y="11.7391" width="12.1304" height="5.65217"/>
  </objectgroup>
 </tile>
 <tile id="2709">
  <objectgroup draworder="index">
   <object id="1" x="1.04348" y="-0.782609" width="13.913" height="16.6522"/>
  </objectgroup>
 </tile>
 <tile id="2710">
  <objectgroup draworder="index">
   <object id="1" x="0.782609" y="-0.608696" width="14.4348" height="16.6957"/>
  </objectgroup>
 </tile>
 <tile id="2711">
  <objectgroup draworder="index">
   <object id="1" x="0.956522" y="-0.695652" width="14.2174" height="16.6522"/>
  </objectgroup>
 </tile>
 <tile id="2712">
  <objectgroup draworder="index">
   <object id="1" x="0.869565" y="-0.608696" width="14.2609" height="16.7391"/>
  </objectgroup>
 </tile>
 <tile id="2713">
  <objectgroup draworder="index">
   <object id="1" x="1" y="-0.608696" width="14.087" height="16.7391"/>
  </objectgroup>
 </tile>
 <tile id="3939">
  <objectgroup draworder="index">
   <object id="6" x="7.91304" y="-0.130435" width="8.17391" height="16.1739"/>
  </objectgroup>
 </tile>
 <tile id="3940">
  <objectgroup draworder="index">
   <object id="1" x="0" y="-0.0434783" width="8" height="16.1304"/>
  </objectgroup>
 </tile>
 <tile id="3942">
  <objectgroup draworder="index">
   <object id="1" x="6" y="-0.347826" width="10.1304" height="16.6522"/>
  </objectgroup>
 </tile>
 <tile id="3943">
  <objectgroup draworder="index">
   <object id="1" x="-0.0434783" y="-0.391304" width="6.04348" height="16.5652"/>
  </objectgroup>
 </tile>
 <tile id="4033">
  <objectgroup draworder="index">
   <object id="1" x="7.95652" y="-0.26087" width="8.17391" height="16.3043"/>
  </objectgroup>
 </tile>
 <tile id="4034">
  <objectgroup draworder="index">
   <object id="1" x="-0.0869565" y="-0.0869565" width="8.17391" height="16.2174"/>
   <object id="2" x="7.17391" y="5.95652" width="9" height="10"/>
  </objectgroup>
 </tile>
 <tile id="4035">
  <objectgroup draworder="index">
   <object id="1" x="-0.0434783" y="5.78261" width="16.1304" height="10.2609"/>
  </objectgroup>
 </tile>
 <tile id="4036">
  <objectgroup draworder="index">
   <object id="2" x="5.82609" y="-0.521739" width="10.2174" height="16.4783"/>
   <object id="3" x="-1.08696" y="6.04348" width="17.4348" height="9.86957"/>
  </objectgroup>
 </tile>
 <tile id="4037">
  <objectgroup draworder="index">
   <object id="1" x="-0.173913" y="-0.521739" width="6.30435" height="16.5217"/>
  </objectgroup>
 </tile>
 <tile id="4127">
  <objectgroup draworder="index">
   <object id="2" x="8.78261" y="-1.30435" width="7.52174" height="7.52174"/>
  </objectgroup>
 </tile>
 <tile id="4128">
  <objectgroup draworder="index">
   <object id="1" x="-0.0869565" y="-0.26087" width="16.1739" height="6.34783"/>
  </objectgroup>
 </tile>
 <tile id="4129">
  <objectgroup draworder="index">
   <object id="1" x="-0.26087" y="-0.565217" width="16.3478" height="5.69565"/>
  </objectgroup>
 </tile>
 <tile id="4130">
  <objectgroup draworder="index">
   <object id="1" x="-0.173913" y="-0.217391" width="16.2609" height="6.43478"/>
  </objectgroup>
 </tile>
 <tile id="4131">
  <objectgroup draworder="index">
   <object id="1" x="-0.434783" y="-0.608696" width="5.65217" height="5.91304"/>
  </objectgroup>
 </tile>
</tileset>
